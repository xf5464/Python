# Kinds

K_DIR = 'dir'
K_FILE = 'file'

# Repository location types

LT_URL = 'url'
LT_PATH = 'path'
